INSERT INTO test_table (parameter_text, parameter_int) VALUES ('shirt', 111);
INSERT INTO test_table (parameter_text, parameter_int) VALUES ('boots', 222);
INSERT INTO test_table (parameter_text, parameter_int) VALUES ('gloves', 333);