DROP TABLE test_table;
CREATE TABLE test_table(id INTEGER not null primary key AUTO_INCREMENT, parameter_text VARCHAR(50), parameter_int INTEGER);